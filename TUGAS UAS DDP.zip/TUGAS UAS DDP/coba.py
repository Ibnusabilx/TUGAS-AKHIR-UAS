import streamlit as st
import base64

# CSS untuk memberi efek transparan dan agak putih dengan blur pada latar belakang form
st.markdown("""
    <style>
        /* Mengubah latar belakang form dengan transparansi dan efek blur */
        .streamlit-expanderHeader, .streamlit-form {
            background-color: rgba(255, 255, 255, 0.7) !important;  /* Latar belakang putih samar dengan transparansi */
            backdrop-filter: blur(10px);  /* Efek blur pada latar belakang */
            -webkit-backdrop-filter: blur(10px);  /* Mendukung browser berbasis WebKit seperti Safari */
        }

        /* Mengubah latar belakang container di form (opsional) */
        .streamlit-container {
            background-color: rgba(255, 255, 255, 0.7) !important;  /* Latar belakang putih samar dengan transparansi */
            backdrop-filter: blur(10px);  /* Efek blur pada container */
            -webkit-backdrop-filter: blur(10px);  /* Mendukung browser berbasis WebKit */
        }

        /* Mengubah warna latar belakang widget teks input dengan efek blur */
        .stTextInput, .stTextArea, .stSelectbox, .stRadio {
            background-color: rgba(255, 255, 255, 0.7) !important; /* Latar belakang putih samar untuk input */
            backdrop-filter: blur(5px);  /* Efek blur lebih ringan untuk input */
            -webkit-backdrop-filter: blur(5px);  /* Mendukung browser berbasis WebKit */
        }
    </style>
""", unsafe_allow_html=True)

# Form atau input Streamlit
st.header("Formulir Input dengan Latar Belakang Transparan dan Agak Putih")


# Fungsi untuk membaca gambar lokal dan mengkonversinya ke Base64
def image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode()

# Mengubah gambar lokal menjadi Base64
image_path = "img/background (2).jpg"  # Pastikan gambar berada di folder yang sama dengan file .py
image_base64 = image_to_base64(image_path)

# Contoh form input
name = st.text_input("Nama")
email = st.text_input("Email")
message = st.text_area("Pesan")

# Menampilkan hasil input
if st.button("Kirim"):
    st.write(f"Nama: {name}")
    st.write(f"Email: {email}")
    st.write(f"Pesan: {message}")


